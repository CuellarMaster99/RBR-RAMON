// ESP32 + L298N + 2x HC-SR04 (lógica solicitada)
// Condición de giro DERECHA/RIGHT (RIGHT = motor IN1/IN2):
//   - HC1 (TRIG=4,ECHO=18) <= 3.3 cm  Y  HC2 (TRIG=16,ECHO=19) <= 5.0 cm  -> GIRAR DERECHA:
//       IN1/IN2 = ATRÁS (cambia) ; IN3/IN4 = ATRÁS (se mantiene preestablecido)
//   - En cualquier otro caso -> MODO BASE (adelante “preestablecido”):
//       IN1/IN2 = ADELANTE ; IN3/IN4 = ATRÁS

#if !defined(ARDUINO_ARCH_ESP32)
#error "Selecciona ESP32 Dev Module en Herramientas > Placa."
#endif

// --------- Pines HC-SR04 ---------
#define TRIG1_PIN   4
#define ECHO1_PIN   18  // ¡OJO! ECHO a 5V -> divisor a 3.3V

#define TRIG2_PIN   16
#define ECHO2_PIN   19  // ¡OJO! ECHO a 5V -> divisor a 3.3V

// --------- Pines L298N ---------
#define ENA_PIN   14    // RIGHT/DERECHA = IN1/IN2
#define IN1_PIN   13
#define IN2_PIN   12

#define ENB_PIN   26    // Motor "izquierdo" lógico en este cableado (IN3/IN4)
#define IN3_PIN   27
#define IN4_PIN   33

// --------- Parámetros ----------
#define ENTER1_CM         3.3f   // umbral HC1
#define ENTER2_CM         5.0f   // umbral HC2
#define SPEED_BASE_DUTY   200
#define FILTER_SAMPLES    3

// --- Modo de operación ---
enum Mode { M_BASE_FORWARD, M_RIGHT_TURN };
void aplicarModo(Mode m);
Mode modo = M_BASE_FORWARD;

// --- HC-SR04 helpers ---
const float SOUND_SPEED_CM_PER_US = 0.0343f;
const uint32_t ECHO_TIMEOUT_US     = 25000;

float medirDistanciaCM(uint8_t trig, uint8_t echo) {
  digitalWrite(trig, LOW);  delayMicroseconds(2);
  digitalWrite(trig, HIGH); delayMicroseconds(10);
  digitalWrite(trig, LOW);
  uint32_t dur = pulseIn(echo, HIGH, ECHO_TIMEOUT_US);
  if (dur == 0) return NAN;
  return (dur * SOUND_SPEED_CM_PER_US) * 0.5f;
}

float distanciaFiltradaCM(uint8_t trig, uint8_t echo, uint8_t n = FILTER_SAMPLES) {
  float acc = 0; uint8_t ok = 0;
  for (uint8_t i = 0; i < n; i++) {
    float d = medirDistanciaCM(trig, echo);
    if (!isnan(d)) { acc += d; ok++; }
    delay(15);
  }
  return ok ? (acc / ok) : NAN;
}

// --- Motores (L298N) ---
// dir: +1 = adelante, -1 = atrás, 0 = freno
void motorRight_IN1IN2(int duty, int dir) { // RIGHT/DERECHA
  if (dir > 0)      { digitalWrite(IN1_PIN, HIGH); digitalWrite(IN2_PIN, LOW);  }
  else if (dir < 0) { digitalWrite(IN1_PIN, LOW);  digitalWrite(IN2_PIN, HIGH); }
  else              { digitalWrite(IN1_PIN, LOW);  digitalWrite(IN2_PIN, LOW);  }
  analogWrite(ENA_PIN, constrain(duty, 0, 255));
}
void motorLeft_IN3IN4(int duty, int dir) {
  if (dir > 0)      { digitalWrite(IN3_PIN, HIGH); digitalWrite(IN4_PIN, LOW);  }
  else if (dir < 0) { digitalWrite(IN3_PIN, LOW);  digitalWrite(IN4_PIN, HIGH); }
  else              { digitalWrite(IN3_PIN, LOW);  digitalWrite(IN4_PIN, LOW);  }
  analogWrite(ENB_PIN, constrain(duty, 0, 255));
}

// M_BASE_FORWARD: RIGHT (IN1/IN2)=adelante ; LEFT (IN3/IN4)=atrás (preestablecido)
// M_RIGHT_TURN : RIGHT (IN1/IN2)=atrás    ; LEFT (IN3/IN4)=atrás (se mantiene)
void aplicarModo(Mode m) {
  if (m == M_BASE_FORWARD) {
    motorRight_IN1IN2(SPEED_BASE_DUTY, +1); // DERECHA ADELANTE
    motorLeft_IN3IN4 (SPEED_BASE_DUTY, -1); // IZQUIERDA ATRÁS (preestablecido, NO cambia)
  } else { // M_RIGHT_TURN
    motorRight_IN1IN2(SPEED_BASE_DUTY, -1); // DERECHA ATRÁS (solo aquí cambia)
    motorLeft_IN3IN4 (SPEED_BASE_DUTY, -1); // IZQUIERDA ATRÁS (se mantiene igual)
  }
}

void setup() {
  Serial.begin(115200);

  pinMode(TRIG1_PIN, OUTPUT);
  pinMode(ECHO1_PIN, INPUT);
  pinMode(TRIG2_PIN, OUTPUT);
  pinMode(ECHO2_PIN, INPUT);

  pinMode(IN1_PIN, OUTPUT);
  pinMode(IN2_PIN, OUTPUT);
  pinMode(IN3_PIN, OUTPUT);
  pinMode(IN4_PIN, OUTPUT);
  pinMode(ENA_PIN, OUTPUT);
  pinMode(ENB_PIN, OUTPUT);

  aplicarModo(M_BASE_FORWARD);
  Serial.println("Regla:");
  Serial.println("  SI (HC1<=3.3cm Y HC2<=5cm) -> RIGHT gira (IN1/IN2 ATRÁS), IN3/IN4 se mantiene ATRÁS");
  Serial.println("  EN OTRO CASO -> base: RIGHT ADELANTE | IN3/IN4 ATRÁS");
}

void loop() {
  float d1 = distanciaFiltradaCM(TRIG1_PIN, ECHO1_PIN);
  float d2 = distanciaFiltradaCM(TRIG2_PIN, ECHO2_PIN);

  bool cond = (!isnan(d1) && !isnan(d2) && d1 <= ENTER1_CM && d2 <= ENTER2_CM);

  Mode nuevo = cond ? M_RIGHT_TURN : M_BASE_FORWARD;

  if (nuevo != modo) {
    modo = nuevo;
    aplicarModo(modo);
    if (modo == M_RIGHT_TURN) {
      Serial.print("HC1<= "); Serial.print(ENTER1_CM,1);
      Serial.print(" cm Y HC2<= "); Serial.print(ENTER2_CM,1);
      Serial.println(" cm -> GIRAR DERECHA (IN1/IN2 ATRÁS; IN3/IN4 igual)");
    } else {
      Serial.println("Condición NO se cumple -> MODO BASE (IN1/IN2 ADELANTE; IN3/IN4 ATRÁS)");
    }
  }

  // (Opcional) mostrar distancias
  if (!isnan(d1) && !isnan(d2)) {
    Serial.print("D1="); Serial.print(d1,1); Serial.print(" cm | ");
    Serial.print("D2="); Serial.print(d2,1); Serial.println(" cm");
  } else {
    Serial.println("Distancia: N/A en uno o ambos sensores");
  }

  delay(20);
}
